import { defineTool } from "@lovable.dev/mcp-js";

export default defineTool({
  name: "get_contact_info",
  title: "Get contact information",
  description:
    "Get Antam Homes contact details and how an apartment owner can start a no-obligation conversation about their apartment.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const info = {
      company: "Donut Point, s.r.o.",
      companyId: "21904022",
      registeredSeat: "Příčná 1892/4, Nové Město, 110 00 Praha 1",
      brand: "Antam Homes",
      email: "antamhomes@gmail.com",
      phone: "727 952 459",
      officePhone: "607 338 126",
      vietnamesePhone: "776 607 003",
      website: "https://www.antamhomes.com",
      vietnameseVersion: "https://www.antamhomes.com/vn",
      serviceArea: "Praha a okolí",
      languages: ["čeština", "Tiếng Việt"],
    };
    return {
      content: [
        {
          type: "text" as const,
          text: `Antam Homes (Donut Point, s.r.o., IČO 21904022)\nEmail: ${info.email}\nTelefon: ${info.phone}\nKancelář: ${info.officePhone}\nTiếng Việt: ${info.vietnamesePhone}\nWeb: ${info.website} (Vietnamese: ${info.vietnameseVersion})\nOblast: ${info.serviceArea}`,
        },
      ],
      structuredContent: info,
    };
  },
});